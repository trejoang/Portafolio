import { Injectable } from '@angular/core';
import { Eventos } from '../Entidad/Eventos';
import { HttpClient } from '@angular/common/http';
import { Costos } from '../Entidad/Costos';
import { Usuarios } from '../Entidad/Usuarios';
import { Ubicaciones } from '../Entidad/Ubicaciones';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceWSService {

  constructor(private http: HttpClient) { }

  url = "http://localhost:9000";

  listarEWS(){
    return this.http.get<Eventos[]>(this.url + "/E");
  }
  guardarEWS(evento : Eventos){
    return this.http.post<Eventos[]>(this.url + "/E", evento);
  }
  editarEWS(evento: Eventos) {
    const url = `${this.url}/E/${evento.idEvento}`;  
    return this.http.put(url, evento);  
  }
  eliminarEWS(idEvento: Number): Observable<any> {
    return this.http.delete(`${this.url}/E/${idEvento}`);
  }
  listartodo(eventoId: number): Observable<any> {
    return this.http.get<any>(`${this.url}/E/todo/${eventoId}`);
  }
  //PARA LISTAR TODO 
listarTodo(eventoId: number): Observable<any> {
  return this.http.get<any>(`${this.url}/E/todo/${eventoId}`);
}

  

  //editarEWS(evento : Eventos){
    //     return this.http.put<Eventos>(this.url + "/E/{idEvento}", evento, {responseType : "text" as "json"});
     //}

// Costos
  listarCWS(){
    return this.http.get<Costos[]>(this.url + "/C");
  }
  guardarCWS(costo : Costos){
    return this.http.post<Costos[]>(this.url + "/C", costo);
  }
  editarCWS(costo: Costos) {
    const url = `${this.url}/C/${costo.idCosto}`;  
    return this.http.put(url, costo);  
  }

  eliminarCWS(idCosto : Number): Observable<any> {
    return this.http.delete(`${this.url}/C/${idCosto}`);
  }

//Usuarios
  listarUWS(){
    return this.http.get<Usuarios[]>(this.url + '/U');
  }
  guardarUWS(usuario : Usuarios){
    return this.http.post<Usuarios[]>(this.url + "/U", usuario);
  }
  editaUWS(usuario: Usuarios) {
    const url = `${this.url}/U/${usuario.idUsuario}`;  
    return this.http.put(url, usuario);  
  }
  eliminarUWS(idUsuario : Number): Observable<any> {
    return this.http.delete(`${this.url}/U/${idUsuario}`);
  }

//Ubicaciones
listarUBWS(){
  return this.http.get<Ubicaciones[]>(this.url + "/ub");
}
guardarUBWS(ubicacion : Ubicaciones){
  return this.http.post<Ubicaciones[]>(this.url + "/ub", ubicacion);
}
editarUBWS(ubicacion : Ubicaciones){
    const url = `${this.url}/ub/${ubicacion.ubicacionId}`;  
    return this.http.put(url, ubicacion);  
}
eliminarUBWS(ubicacionId : Number): Observable<any> {
  return this.http.delete(`${this.url}/ub/${ubicacionId}`);
}

}
