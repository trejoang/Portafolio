export class Usuarios{
    idUsuario !: Number;
    tipoUsuario !: String;
    nombre !: String;
    contrasena !: Number;
    fechaCreacion !: String;
    costoId !: Number;
    eventoId !: Number;
}