export class Costos{
    idCosto !: Number;
    costoEntrada !: Number;
    categoria !: String;
    eventoId !: Number;
}