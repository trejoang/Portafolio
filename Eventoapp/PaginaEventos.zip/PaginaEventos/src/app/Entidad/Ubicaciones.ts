export class Ubicaciones{
    ubicacionId !: Number;
    eventoId !: Number;
    nombreLugar !: String;
    ubicacion !: String;
}