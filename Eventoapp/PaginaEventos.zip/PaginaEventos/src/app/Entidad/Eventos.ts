export class Eventos{
    idEvento !: Number;
    nombre !: String;
    fechaHora !: Date;
    estrellasInvitadas !: String;
    totalAsistencia !: Number
}