import { Component } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'PaginaEventos';

  constructor(private router : Router){}

  lisatrE(){
    this.router.navigate(['listarE']);
  }
  guardarE(){
    this.router.navigate(['guardarE']);
  }
  editarE(){
    this.router.navigate(['editarE']);
  }
  listartodo(){
    this.router.navigate(['listartodo']);
  }

  //Metodos para costos
  listarC(){
    this.router.navigate(['listarC']);
  }
  guardarC(){
    this.router.navigate(['guardarC']);
  }
  editarC(){
    this.router.navigate(['editarC']);
  }

  //Metodos para Usuarios
  listarU(){
    this.router.navigate(['listarU']);
  }
  guardarU(){
    this.router.navigate(['guardarU']);
  }
  editarU(){
    this.router.navigate(['editarU']);
  }

  //Metodos para ubicaciones
  listarUb(){
    this.router.navigate(['listarUb']);
  }
  guardarUb(){
    this.router.navigate(['guardarUb']);
  }
  editarUb(){
    this.router.navigate(['editarUb']);
  }

}
