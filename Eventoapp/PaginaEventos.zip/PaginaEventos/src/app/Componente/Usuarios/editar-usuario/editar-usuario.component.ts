import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import { Usuarios } from '../../../Entidad/Usuarios';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editar-usuario',
  imports: [FormsModule],
  templateUrl: './editar-usuario.component.html',
  styleUrl: './editar-usuario.component.css'
})
export class EditarUsuarioComponent {

  constructor(private router : Router, private service : ServiceWSService){}

  usuario : Usuarios = new Usuarios();

  validarCampos():boolean{
        if(!this.usuario.idUsuario|| !this.usuario.tipoUsuario ||!this.usuario.nombre || !this.usuario.contrasena
          || !this.usuario.fechaCreacion|| !this.usuario.costoId|| !this.usuario.eventoId){
          Swal.fire({
            icon: 'warning',
            title: 'Campos Incompletos',
            text: 'COMPLETAR DATOS',
            showConfirmButton: true
          });
          return false;
        }
        return true;
      }

      editarC() {
                  if (!this.validarCampos()) {
                    return;
                  }
                  this.service.editaUWS(this.usuario).subscribe(
                    (data) => {
                      Swal.fire({
                        icon: 'success',
                        title: 'EDITAR',
                        text: 'OCURRIO UN ERROR AL GUARDAR',
                        showConfirmButton: true,
                        timer: 2000
                      });
                      this.router.navigate(['listarU']);  
                      console.log(JSON.stringify(data));  
                    },
                    (error) => {
                      Swal.fire({
                        icon: 'success',
                        title: 'EDITAR',
                        text: 'USUARIO EDITADO',
                        showConfirmButton: false,
                        timer: 2000
                      });
                      this.router.navigate(['listarU']); 
                      console.log(JSON.stringify(error));  // Ver detalles del error
                    }
                  );
                }

}
