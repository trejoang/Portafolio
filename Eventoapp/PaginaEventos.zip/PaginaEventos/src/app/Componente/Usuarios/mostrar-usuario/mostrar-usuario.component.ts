import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import { Usuarios } from '../../../Entidad/Usuarios';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mostrar-usuario',
  imports: [],
  templateUrl: './mostrar-usuario.component.html',
  styleUrl: './mostrar-usuario.component.css'
})
export class MostrarUsuarioComponent implements OnInit{

  constructor(private router : Router, private service : ServiceWSService){}

  usuario : Usuarios = new Usuarios();
  usuarios !: Usuarios[];

  ngOnInit(): void {
    this.listarU();
  }

  listarU(){
    this.service.listarUWS().subscribe(data =>{
      this.usuarios=data
      console.log('listado correcto: '+ JSON.stringify(data))
    })
  }

  eliminar(usuario: Usuarios) {
        Swal.fire({
          title: "¿Seguro que quieres eliminar este usuario?",
          text: "Esta acción no se puede revertir",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "Sí, elimínalo"
        }).then((result) => {
          if (result.isConfirmed) {
            // Llamamos al servicio para eliminar el evento
            this.service.eliminarUWS(usuario.idUsuario).subscribe(() => {
              // Eliminamos el evento de la lista local
              this.usuarios = this.usuarios.filter(e => e.idUsuario !== usuario.idUsuario);
      
              Swal.fire({
                title: "¡Eliminado!",
                text: "Ocurrió un error al eliminar al usuario. Intenta de nuevo.",
                icon: "error",
              });
              
              // No es necesario redirigir si ya estamos en la misma página
              // this.router.navigate(['listarE']);  // Esto se puede omitir
            }, error => {
              Swal.fire({
                icon: 'success',
                title: 'Eliminado',
                text: 'El usuario se eliminó con éxito',
                showConfirmButton: true
              });
              console.error('Error al eliminar el usuario: ', error);
              //this.router.navigate(['listarE']);
              this.listarU();
            });
          } else if (result.isDenied) {
            Swal.fire("La eliminación fue cancelada", " ", "info");
          }
        });
      }

}
