import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Usuarios } from '../../../Entidad/Usuarios';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-guardar-usuario',
  imports: [FormsModule],
  templateUrl: './guardar-usuario.component.html',
  styleUrl: './guardar-usuario.component.css'
})
export class GuardarUsuarioComponent {

  usuario : Usuarios = new Usuarios();
  
  constructor(private router : Router, private service : ServiceWSService){}

  validarCampos():boolean{
      if( !this.usuario.tipoUsuario ||!this.usuario.nombre || !this.usuario.contrasena
        || !this.usuario.fechaCreacion|| !this.usuario.costoId|| !this.usuario.eventoId){
        Swal.fire({
          icon: 'warning',
          title: 'Campos Incompletos',
          text: 'COMPLETAR DATOS',
          showConfirmButton: true
        });
        return false;
      }
      return true;
    }

    guardar(){
        if(!this.validarCampos()){
          return;
        }
        this.service.guardarUWS(this.usuario).subscribe(data =>{
            Swal.fire({
              icon: 'error',
              title: 'GUARDAR',
              text: 'OCURRIO UN ERROR AL GUARDAR',
              showConfirmButton: false,
              timer: 2000
            });
            console.log(JSON.stringify(data));
            
          },
          (error) =>{
            Swal.fire({
              icon: 'success',
              title: 'GUARDAR',
              text: 'SE GUARDO CORRECTAMENTE',
              showConfirmButton: true,
              timer: 2000
            });
            this.router.navigate(['listarU']);
            console.log(JSON.stringify(error));
          }
        );
      }

}
