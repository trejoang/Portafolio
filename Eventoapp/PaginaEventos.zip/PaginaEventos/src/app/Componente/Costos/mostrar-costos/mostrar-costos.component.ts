import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import { Costos } from '../../../Entidad/Costos';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mostrar-costos',
  imports: [],
  templateUrl: './mostrar-costos.component.html',
  styleUrl: './mostrar-costos.component.css'
})
export class MostrarCostosComponent implements OnInit{

  constructor(private router : Router, private service:ServiceWSService){}

  costo : Costos = new Costos();
  costos !: Costos[];

  ngOnInit(): void {
    this.listarC();
  }

  listarC(){
    this.service.listarCWS().subscribe(data =>{
      this.costos=data
      console.log('listado correcto: '+ JSON.stringify(data))
    })
  }

  eliminar(costo: Costos) {
      Swal.fire({
        title: "¿Seguro que quieres eliminar este costo?",
        text: "Esta acción no se puede revertir",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, elimínalo"
      }).then((result) => {
        if (result.isConfirmed) {
          // Llamamos al servicio para eliminar el evento
          this.service.eliminarCWS(costo.idCosto).subscribe(() => {
            // Eliminamos el evento de la lista local
            this.costos = this.costos.filter(e => e.idCosto !== costo.idCosto);
    
            Swal.fire({
              title: "¡Eliminado!",
              text: "Ocurrió un error al eliminar el costo. Intenta de nuevo.",
              icon: "error",
            });
            
            // No es necesario redirigir si ya estamos en la misma página
            // this.router.navigate(['listarE']);  // Esto se puede omitir
          }, error => {
            Swal.fire({
              icon: 'success',
              title: 'Eliminado',
              text: 'El costo se eliminó con éxito',
              showConfirmButton: true
            });
            console.error('Error al eliminar el costo: ', error);
            //this.router.navigate(['listarE']);
            this.listarC();
          });
        } else if (result.isDenied) {
          Swal.fire("La eliminación fue cancelada", " ", "info");
        }
      });
    }

}
