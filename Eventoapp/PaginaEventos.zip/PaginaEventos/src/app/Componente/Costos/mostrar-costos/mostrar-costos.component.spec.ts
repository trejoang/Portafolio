import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MostrarCostosComponent } from './mostrar-costos.component';

describe('MostrarCostosComponent', () => {
  let component: MostrarCostosComponent;
  let fixture: ComponentFixture<MostrarCostosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MostrarCostosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MostrarCostosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
