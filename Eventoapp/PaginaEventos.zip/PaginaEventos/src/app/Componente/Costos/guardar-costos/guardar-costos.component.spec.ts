import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuardarCostosComponent } from './guardar-costos.component';

describe('GuardarCostosComponent', () => {
  let component: GuardarCostosComponent;
  let fixture: ComponentFixture<GuardarCostosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GuardarCostosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GuardarCostosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
