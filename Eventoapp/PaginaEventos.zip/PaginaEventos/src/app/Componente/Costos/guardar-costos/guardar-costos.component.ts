import { Component } from '@angular/core';
import { Costos } from '../../../Entidad/Costos';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import Swal from 'sweetalert2';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-guardar-costos',
  imports: [FormsModule],
  templateUrl: './guardar-costos.component.html',
  styleUrl: './guardar-costos.component.css'
})
export class GuardarCostosComponent {

  costo: Costos = new Costos();
  constructor(private router: Router, private service: ServiceWSService){}
  
  validarCampos():boolean{
    if( !this.costo.costoEntrada ||!this.costo.categoria || !this.costo.eventoId){
      Swal.fire({
        icon: 'warning',
        title: 'Campos Incompletos',
        text: 'COMPLETAR DATOS',
        showConfirmButton: true
      });
      return false;
    }
    return true;
  }

  guardar(){
    if(!this.validarCampos()){
      return;
    }
    this.service.guardarCWS(this.costo).subscribe(data =>{
        Swal.fire({
          icon: 'error',
          title: 'GUARDAR',
          text: 'OCURRIO UN ERROR AL GUARDAR',
          showConfirmButton: false,
          timer: 2000
        });
        console.log(JSON.stringify(data));
        
      },
      (error) =>{
        Swal.fire({
          icon: 'success',
          title: 'GUARDAR',
          text: 'SE GUARDO CORRECTAMENTE',
          showConfirmButton: true,
          timer: 2000
        });
        this.router.navigate(['listarC']);
        console.log(JSON.stringify(error));
      }
    );
  }

}
