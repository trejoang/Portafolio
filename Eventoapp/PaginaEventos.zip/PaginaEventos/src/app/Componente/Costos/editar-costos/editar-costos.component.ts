import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import { Costos } from '../../../Entidad/Costos';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editar-costos',
  imports: [FormsModule],
  templateUrl: './editar-costos.component.html',
  styleUrl: './editar-costos.component.css'
})
export class EditarCostosComponent {

  constructor(private router : Router, private service : ServiceWSService){}

  costo : Costos = new Costos();

  validarCampos():boolean{
        if(!this.costo.idCosto || !this.costo.costoEntrada || !this.costo.categoria || !this.costo.eventoId ){
          Swal.fire({
            icon: 'warning',
            title: 'Campos Incompletos',
            text: 'COMPLETAR DATOS',
            showConfirmButton: true 
          });
          return false;
        }
        return true;
      }

      editarC() {
            if (!this.validarCampos()) {
              return;
            }
            this.service.editarCWS(this.costo).subscribe(
              (data) => {
                Swal.fire({
                  icon: 'success',
                  title: 'EDITAR',
                  text: 'OCURRIO UN ERROR AL GUARDAR',
                  showConfirmButton: true,
                  timer: 2000
                });
                this.router.navigate(['listarC']);  
                console.log(JSON.stringify(data));  
              },
              (error) => {
                Swal.fire({
                  icon: 'success',
                  title: 'EDITAR',
                  text: 'EVENTO EDITADO',
                  showConfirmButton: false,
                  timer: 2000
                });
                this.router.navigate(['listarC']); 
                console.log(JSON.stringify(error));  // Ver detalles del error
              }
            );
          }

}
