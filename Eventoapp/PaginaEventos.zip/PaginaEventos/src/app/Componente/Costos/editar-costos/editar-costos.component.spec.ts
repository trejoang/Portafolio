import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditarCostosComponent } from './editar-costos.component';

describe('EditarCostosComponent', () => {
  let component: EditarCostosComponent;
  let fixture: ComponentFixture<EditarCostosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditarCostosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditarCostosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
