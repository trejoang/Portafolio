import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MostrarTodosEventosComponent } from './mostrar-todos-eventos.component';

describe('MostrarTodosEventosComponent', () => {
  let component: MostrarTodosEventosComponent;
  let fixture: ComponentFixture<MostrarTodosEventosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MostrarTodosEventosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MostrarTodosEventosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
