import { Component } from '@angular/core';
import { ServiceWSService } from '../../../service/service-ws.service';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-mostrar-todos-eventos',
  imports: [CommonModule,FormsModule],
  templateUrl: './mostrar-todos-eventos.component.html',
  styleUrl: './mostrar-todos-eventos.component.css'
})

export class MostrarTodosEventosComponent {
  eventoId: number = 0;

  eventos: any[] = [];
  costos: any[] = [];
  ubicaciones: any[] = [];
  usuarios: any[] = [];
  
  
  constructor( private service: ServiceWSService){}

  

  buscarEvento() {
    // Verificar si el eventoId es válido antes de hacer la búsqueda
    if (this.eventoId > 0) {
      this.obtenerEventos();
    } else {
      alert("Por favor, ingresa un ID de evento válido.");
    }
  }

  obtenerEventos(){
    this.service.listartodo(this.eventoId).subscribe(
      (data: any) => {
        console.log('Datos obtenidos:', data);
        this.eventos = data["Evento"]||[];
        this.costos = data["Precios por entrada:"]||[]; 
        this.ubicaciones = data["Ubicacion registrada"]||[]; 
        this.usuarios = data["Usuario registrado"]||[]||[]; 
        console.log('Datos obtenidos:', data);

        
      },
      (error) => {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Ocurrió un error al obtener los detalles del evento.',
        });
        console.error(error);
      }
    );
  }

}
