import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import { Eventos } from '../../../Entidad/Eventos';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mostrar-eventos',
  imports: [],
  templateUrl: './mostrar-eventos.component.html',
  styleUrl: './mostrar-eventos.component.css'
})
export class MostrarEventosComponent implements OnInit{

  constructor(private router : Router, private service:ServiceWSService){}

  evento : Eventos = new Eventos();
  eventos !: Eventos[];

  ngOnInit(): void {
      this.listarE();
  }

  listarE(){
    this.service.listarEWS().subscribe(data =>{
      this.eventos=data
      console.log('listado correctop: ' + JSON.stringify(data))
    })
  }

  eliminarEvento(evento: Eventos) {
    Swal.fire({
      title: "¿Seguro que quieres eliminar este evento?",
      text: "Esta acción no se puede revertir",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sí, elimínalo"
    }).then((result) => {
      if (result.isConfirmed) {
        // Llamamos al servicio para eliminar el evento
        this.service.eliminarEWS(evento.idEvento).subscribe(() => {
          // Eliminamos el evento de la lista local
          this.eventos = this.eventos.filter(e => e.idEvento !== evento.idEvento);
  
          Swal.fire({
            title: "¡Eliminado!",
            text: "Ocurrió un error al eliminar el evento. Intenta de nuevo.",
            icon: "error",
          });
          
          // No es necesario redirigir si ya estamos en la misma página
          // this.router.navigate(['listarE']);  // Esto se puede omitir
        }, error => {
          Swal.fire({
            icon: 'success',
            title: 'Eliminado',
            text: 'El evento se eliminó con éxito',
            showConfirmButton: true
          });
          console.error('Error al eliminar el evento: ', error);
          //this.router.navigate(['listarE']);
          this.listarE();
        });
      } else if (result.isDenied) {
        Swal.fire("La eliminación fue cancelada", " ", "info");
      }
    });
  }


}
