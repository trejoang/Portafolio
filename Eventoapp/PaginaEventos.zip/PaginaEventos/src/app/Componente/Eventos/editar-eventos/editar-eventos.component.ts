import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import { Eventos } from '../../../Entidad/Eventos';
import { FormsModule } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editar-eventos',
  imports: [FormsModule],
  templateUrl: './editar-eventos.component.html',
  styleUrl: './editar-eventos.component.css'
})
export class EditarEventosComponent {

  constructor (private router : Router, private service : ServiceWSService){}

  evento : Eventos = new Eventos();

  validarCampos():boolean{
      if(!this.evento.idEvento || !this.evento.nombre || !this.evento.fechaHora || !this.evento.estrellasInvitadas || !this.evento.totalAsistencia){
        Swal.fire({
          icon: 'warning',
          title: 'Campos Incompletos',
          text: 'COMPLETAR DATOS',
          showConfirmButton: true 
        });
        return false;
      }
      return true;
    }

    editarE() {
      if (!this.validarCampos()) {
        return;
      }
      this.service.editarEWS(this.evento).subscribe(
        (data) => {
          Swal.fire({
            icon: 'success',
            title: 'EDITAR',
            text: 'OCURRIO UN ERROR AL GUARDAR',
            showConfirmButton: true,
            timer: 2000
          });
          this.router.navigate(['listarE']);  
          console.log(JSON.stringify(data));  
        },
        (error) => {
          Swal.fire({
            icon: 'success',
            title: 'EDITAR',
            text: 'EVENTO EDITADO',
            showConfirmButton: false,
            timer: 2000
          });
          this.router.navigate(['listarE']); 
          console.log(JSON.stringify(error));  // Ver detalles del error
        }
      );
    }

}
