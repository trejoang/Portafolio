import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuardarEventosComponent } from './guardar-eventos.component';

describe('GuardarEventosComponent', () => {
  let component: GuardarEventosComponent;
  let fixture: ComponentFixture<GuardarEventosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GuardarEventosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GuardarEventosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
