import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Ubicaciones } from '../../../Entidad/Ubicaciones';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-editar-ubicacion',
  imports: [FormsModule],
  templateUrl: './editar-ubicacion.component.html',
  styleUrl: './editar-ubicacion.component.css'
})
export class EditarUbicacionComponent {

  ubicacion : Ubicaciones = new Ubicaciones();
  constructor(private router : Router, private service : ServiceWSService){}

  validarCampos():boolean{
          if(!this.ubicacion.ubicacionId || !this.ubicacion.eventoId || !this.ubicacion.nombreLugar || !this.ubicacion.ubicacion ){
            Swal.fire({
              icon: 'warning',
              title: 'Campos Incompletos',
              text: 'COMPLETAR DATOS',
              showConfirmButton: true 
            });
            return false;
          }
          return true;
        }
    editarUB() {
                if (!this.validarCampos()) {
                  return;
                }
                this.service.editarUBWS(this.ubicacion).subscribe(
                  (data) => {
                    Swal.fire({
                      icon: 'success',
                      title: 'EDITAR',
                      text: 'OCURRIO UN ERROR AL GUARDAR',
                      showConfirmButton: true,
                      timer: 2000
                    });
                    this.router.navigate(['listarUb']);  
                    console.log(JSON.stringify(data));  
                  },
                  (error) => {
                    Swal.fire({
                      icon: 'success',
                      title: 'EDITAR',
                      text: 'UBICACION EDITADA',
                      showConfirmButton: false,
                      timer: 2000
                    });
                    this.router.navigate(['listarUb']); 
                    console.log(JSON.stringify(error));  // Ver detalles del error
                  }
                );
              }

}
