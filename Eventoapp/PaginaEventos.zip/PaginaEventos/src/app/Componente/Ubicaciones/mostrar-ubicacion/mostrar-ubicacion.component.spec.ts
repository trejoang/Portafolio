import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MostrarUbicacionComponent } from './mostrar-ubicacion.component';

describe('MostrarUbicacionComponent', () => {
  let component: MostrarUbicacionComponent;
  let fixture: ComponentFixture<MostrarUbicacionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MostrarUbicacionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MostrarUbicacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
