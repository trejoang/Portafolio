import { Component, OnInit } from '@angular/core';
import { Ubicaciones } from '../../../Entidad/Ubicaciones';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mostrar-ubicacion',
  imports: [],
  templateUrl: './mostrar-ubicacion.component.html',
  styleUrl: './mostrar-ubicacion.component.css'
})
export class MostrarUbicacionComponent implements OnInit{

  constructor(private router : Router, private service:ServiceWSService){}

  ubicacion : Ubicaciones = new Ubicaciones();
  ubicaciones !: Ubicaciones[];

  ngOnInit(): void {
    this.listarUb();
  }

  listarUb(){
    this.service.listarUBWS().subscribe(data =>{
      this.ubicaciones=data
      console.log('listado correcto: ' + JSON.stringify(data))
    })
  }
  eliminar(ubicacion: Ubicaciones) {
        Swal.fire({
          title: "¿Seguro que quieres eliminar este costo?",
          text: "Esta acción no se puede revertir",
          icon: "warning",
          showCancelButton: true,
          confirmButtonColor: "#3085d6",
          cancelButtonColor: "#d33",
          confirmButtonText: "Sí, elimínalo"
        }).then((result) => {
          if (result.isConfirmed) {
            // Llamamos al servicio para eliminar el evento
            this.service.eliminarUBWS(ubicacion.ubicacionId).subscribe(() => {
              // Eliminamos el evento de la lista local
              this.ubicaciones = this.ubicaciones.filter(e => e.ubicacionId !== ubicacion.ubicacionId);
      
              Swal.fire({
                title: "¡Eliminado!",
                text: "Ocurrió un error al eliminar la ubicacion. Intenta de nuevo.",
                icon: "error",
              });
              
              // No es necesario redirigir si ya estamos en la misma página
              // this.router.navigate(['listarE']);  // Esto se puede omitir
            }, error => {
              Swal.fire({
                icon: 'success',
                title: 'Eliminado',
                text: 'La ubicacion se eliminó con éxito',
                showConfirmButton: true
              });
              console.error('Error al eliminar la ubicacion: ', error);
              //this.router.navigate(['listarE']);
              this.listarUb();
            });
          } else if (result.isDenied) {
            Swal.fire("La eliminación fue cancelada", " ", "info");
          }
        });
      }

}
