import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Ubicaciones } from '../../../Entidad/Ubicaciones';
import { Router } from '@angular/router';
import { ServiceWSService } from '../../../service/service-ws.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-guardar-ubicacion',
  imports: [FormsModule],
  templateUrl: './guardar-ubicacion.component.html',
  styleUrl: './guardar-ubicacion.component.css'
})
export class GuardarUbicacionComponent {

  ubicacion : Ubicaciones = new Ubicaciones();
  constructor(private router : Router, private service : ServiceWSService){}

  validarCampos():boolean{
      if( !this.ubicacion.eventoId ||!this.ubicacion.nombreLugar || !this.ubicacion.ubicacion){
        Swal.fire({
          icon: 'warning',
          title: 'Campos Incompletos',
          text: 'COMPLETAR DATOS',
          showConfirmButton: true
        });
        return false;
      }
      return true;
    }

    guardar(){
        if(!this.validarCampos()){
          return;
        }
        this.service.guardarUBWS(this.ubicacion).subscribe(data =>{
            Swal.fire({
              icon: 'error',
              title: 'GUARDAR',
              text: 'OCURRIO UN ERROR AL GUARDAR',
              showConfirmButton: false,
              timer: 2000
            });
            console.log(JSON.stringify(data));
            
          },
          (error) =>{
            Swal.fire({
              icon: 'success',
              title: 'GUARDAR',
              text: 'SE GUARDO CORRECTAMENTE',
              showConfirmButton: true,
              timer: 2000
            });
            this.router.navigate(['listarUb']);
            console.log(JSON.stringify(error));
          }
        );
      }

}
