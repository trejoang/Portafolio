import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuardarUbicacionComponent } from './guardar-ubicacion.component';

describe('GuardarUbicacionComponent', () => {
  let component: GuardarUbicacionComponent;
  let fixture: ComponentFixture<GuardarUbicacionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GuardarUbicacionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GuardarUbicacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
