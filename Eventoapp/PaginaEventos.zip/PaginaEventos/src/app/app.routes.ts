import { Routes } from '@angular/router';
import { GuardarEventosComponent } from './Componente/Eventos/guardar-eventos/guardar-eventos.component';
import { MostrarEventosComponent } from './Componente/Eventos/mostrar-eventos/mostrar-eventos.component';
import { MostrarCostosComponent } from './Componente/Costos/mostrar-costos/mostrar-costos.component';
import { GuardarCostosComponent } from './Componente/Costos/guardar-costos/guardar-costos.component';
import { MostrarUsuarioComponent } from './Componente/Usuarios/mostrar-usuario/mostrar-usuario.component';
import { MostrarUbicacionComponent } from './Componente/Ubicaciones/mostrar-ubicacion/mostrar-ubicacion.component';
import { EditarEventosComponent } from './Componente/Eventos/editar-eventos/editar-eventos.component';
import { EditarCostosComponent } from './Componente/Costos/editar-costos/editar-costos.component';
import { GuardarUsuarioComponent } from './Componente/Usuarios/guardar-usuario/guardar-usuario.component';
import { EditarUsuarioComponent } from './Componente/Usuarios/editar-usuario/editar-usuario.component';
import { GuardarUbicacionComponent } from './Componente/Ubicaciones/guardar-ubicacion/guardar-ubicacion.component';
import { EditarUbicacionComponent } from './Componente/Ubicaciones/editar-ubicacion/editar-ubicacion.component';
import { MostrarTodosEventosComponent } from './Componente/Eventos/mostrar-todos-eventos/mostrar-todos-eventos.component';
export const routes: Routes = [

    {path : 'listarE', component : MostrarEventosComponent},
    {path : 'guardarE', component : GuardarEventosComponent},
    {path : 'editarE', component : EditarEventosComponent},
    {path : 'listartodo', component : MostrarTodosEventosComponent},
    //costos
    {path : 'listarC', component : MostrarCostosComponent},
    {path : 'guardarC', component : GuardarCostosComponent},
    {path : 'editarC', component : EditarCostosComponent},
    //Usuarios
    {path : 'listarU', component : MostrarUsuarioComponent},
    {path : 'guardarU', component : GuardarUsuarioComponent},
    {path : 'editarU', component :EditarUsuarioComponent},
    //Ubicaciones
    {path : 'listarUb', component : MostrarUbicacionComponent},
    {path : 'guardarUb', component : GuardarUbicacionComponent},
    {path : 'editarUb', component : EditarUbicacionComponent}

];
