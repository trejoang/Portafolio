import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Retiro } from '../Entidad/Retiro';
import Swal from 'sweetalert2';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceWSService {

  

  url = 'http://localhost:8003/api/cajero/retiro'

  constructor(private http: HttpClient) { }

   retirar(monto : number): Observable<any>{
    return this.http.post<any>(this.url,{monto});
   }
}
