import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';  // Importa HttpClientModule
import { ServiceWSService } from './service/service-ws.service';


@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  imports: [CommonModule, FormsModule, HttpClientModule]  // Asegúrate de incluir HttpClientModule
})
export class AppComponent {
  title = 'Cajero Automático';
  monto: number = 0;
  resultado: any;

  constructor(private cajers : ServiceWSService){}

  retirar() {
    this.cajers.retirar(this.monto).subscribe(
      (data) => {
        this.resultado = Object.entries(data).map(([key, value]) => `${key}: ${value}`);
      },
      (error) => {
        console.error('Error: No se pudo procesar la solicitud', error);
        this.resultado = ['Sobrepasate el monto del cajero'];
      }
    );
  }
}
