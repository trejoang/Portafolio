export class Retiro{
    monto !:number;
}