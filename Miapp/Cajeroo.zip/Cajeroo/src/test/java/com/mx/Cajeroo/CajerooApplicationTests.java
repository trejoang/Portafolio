package com.mx.Cajeroo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CajerooApplicationTests {

	@Test
	void contextLoads() {
	}

}
