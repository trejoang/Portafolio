package com.mx.Clientes.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.mx.Clientes.Entity.Clientes;
import com.mx.Clientes.Repository.ClientesRepository;

@Service  // no olvidar la notacion 
public class ClientesServiceImp implements IClientesService{
	
	@Autowired
	private ClientesRepository dao;

	@Override
	public List<Clientes> listar() {
		// TODO Auto-generated method stub
		return dao.findAll(Sort.by(Sort.Direction.ASC, "idCliente"));
	}

	@Override
	public void guardar(Clientes clientes) {
		// TODO Auto-generated method stub
		dao.save(clientes);
	}

	@Override
	public void eliminar(int idCliente) {
		// TODO Auto-generated method stub
		dao.deleteById(idCliente);
	}

	@Override
	public void editar(Clientes clientes) {
		// TODO Auto-generated method stub
		dao.save(clientes);
	}

	@Override
	public Clientes buscar(int idCliente) {
		// TODO Auto-generated method stub
		return dao.findById(idCliente).orElse(null);
	}
	
	//metodo para buscar por veterinaria
	public List<Clientes> buscarPorVeterinaria(int veterinariaId){
		return dao.findByVeterinariaId(veterinariaId);
		
	}

}
