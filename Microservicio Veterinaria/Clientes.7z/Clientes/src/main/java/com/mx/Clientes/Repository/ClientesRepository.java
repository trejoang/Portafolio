package com.mx.Clientes.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mx.Clientes.Entity.Clientes;

@Repository
public interface ClientesRepository extends JpaRepository<Clientes, Integer>{
	
	public List<Clientes> findByVeterinariaId(int veterinariaId);

}
