package com.mx.Clientes.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mx.Clientes.Entity.Clientes;
import com.mx.Clientes.Service.ClientesServiceImp;

@RestController
@RequestMapping(path = "/C")
public class ClientesWS {
	
	@Autowired
	private ClientesServiceImp service;
	

	//url  http://localhost:8012/U
	
	//listar
		@GetMapping
		public ResponseEntity<?> listar(){
			List<Clientes> clientes = service.listar();
			if(clientes.isEmpty()) {
				return ResponseEntity.ofNullable("no existen clientes");
			}else {
				return ResponseEntity.ok(clientes);
			}
		}
		
		//guardar
				@PostMapping
				public ResponseEntity<?> guardar (@RequestBody Clientes clientes){
					try {
						Clientes encontrado = service.buscar(clientes.getIdCliente());
						if(encontrado == null) {
							service.guardar(clientes);
							return ResponseEntity.ok("Cliente guardado");
						}else {
							return ResponseEntity.status(HttpStatus.FOUND).body("El cliente ya existe en la bd");
						}
					}catch(IllegalArgumentException e) {
						return ResponseEntity.status(HttpStatus.CONFLICT).build();
					}
				}
				
				//buscar
				@PostMapping(path ="{idCliente}")
				public ResponseEntity<?> buscar(@PathVariable("idCliente")int idCliente){
					Clientes encontrado = service.buscar(idCliente);
					if(encontrado != null) {
						return ResponseEntity.ok(encontrado);
					}else {
						return ResponseEntity.ofNullable("El Cliente no se encuentra en la bd");
					}
				}
				
				
				//eliminar
				@DeleteMapping(path = "/{idCliente}")
				public ResponseEntity<?> eliminar(@PathVariable("idCliente")int idCliente){
					Clientes client = service.buscar(idCliente);
					if(client != null) {
						service.eliminar(idCliente);
						return ResponseEntity.ok("Cliente eliminado con exito");
					}else {
						return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente no existente");
					}
				}
				
				
				//editar
				@PutMapping
				public ResponseEntity<?> editar(@RequestBody Clientes clientes){
					try {
						Clientes existente = service.buscar(clientes.getIdCliente());
						
						if(existente == null) {
							return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Este Cliente no eixste en el sistema");
						}else {
							service.editar(clientes);
							return ResponseEntity.ok("El Clientes se edito corretamente");
						}
					}catch(IllegalArgumentException e) {
						return ResponseEntity.status(HttpStatus.CONFLICT).build();
					}
				}
				
				//editar
				@PutMapping(path = "/{idCliente}")
			    public ResponseEntity<?> editar(@PathVariable("idCliente") int idCliente, @RequestBody Clientes clientes) {
					Clientes encontrado = service.buscar(idCliente);
			        if(encontrado != null) {
			            // Actualizamos el evento con los nuevos datos 
			        	clientes.setIdCliente(idCliente); // Aseguramos que el ID no cambie
			            service.editar(clientes);
			            return ResponseEntity.ok("El registro fue actualizado con éxito");
			        } else {
			            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el registro para editar");
			        }
			    }
				
				//busca por veterinaria
				@GetMapping(path ="buscarPorVeterinaria/{veterinariaId}")
				public ResponseEntity<?> buscarPorVeterinaria(@PathVariable ("veterinariaId")int veterinariaId){
					List<Clientes> cli = service.buscarPorVeterinaria(veterinariaId);
					return ResponseEntity.ok(cli);
				}


}
