package com.mx.Clientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
