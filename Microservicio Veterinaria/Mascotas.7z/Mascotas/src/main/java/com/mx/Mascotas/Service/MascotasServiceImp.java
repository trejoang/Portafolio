package com.mx.Mascotas.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.mx.Mascotas.Entity.Mascotas;
import com.mx.Mascotas.Repository.IMascotaRepository;
@Service
public class MascotasServiceImp implements IMascotasService{
	
	@Autowired
	private IMascotaRepository dao;

	@Override
	public List<Mascotas> listar() {
		// TODO Auto-generated method stub
		return dao.findAll(Sort.by(Sort.Direction.ASC, "idMascota"));
	}

	@Override
	public void guardar(Mascotas mascotas) {
		// TODO Auto-generated method stub
		dao.save(mascotas);
	}

	@Override
	public Mascotas buscar(int idMascota) {
		// TODO Auto-generated method stub
		return dao.findById(idMascota).orElse(null);
	}

	@Override
	public void editar(Mascotas mascotas) {
		// TODO Auto-generated method stub
		dao.save(mascotas);
	}

	@Override
	public void eliminar(int idMascota) {
		// TODO Auto-generated method stub
		dao.deleteById(idMascota);
	}
	
	//metodo para buscar por veterinaria
			public List<Mascotas> buscarPorVeterinaria(int veterinariaId){
				return dao.findByVeterinariaId(veterinariaId);
				
			}

}
