package com.mx.Mascotas.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mx.Mascotas.Entity.Mascotas;
import com.mx.Mascotas.Service.MascotasServiceImp;

@RestController
@RequestMapping(path = "/M")
public class MascotasWS {
	
	@Autowired
	private MascotasServiceImp service;
	
	//url  http://localhost:8016/R
	
			@GetMapping
			public ResponseEntity<?> listar(){
				List<Mascotas> mas = service.listar();
				if(mas.isEmpty()) {
					return ResponseEntity.ofNullable("No hay registros disponibles");
				}else {
					return ResponseEntity.ok(mas);
				}
			}
			
			//Guardar
			@PostMapping
			public ResponseEntity<?> guardar(@RequestBody Mascotas mascota){
				Mascotas mas = service.buscar(mascota.getIdMascota());
				if(mas == null) {
					service.guardar(mascota);
					return ResponseEntity.ok("El registro de la Mascotas se guardo con exito");
				}else {
					return ResponseEntity.status(HttpStatus.FOUND).body("Este Registro ya Existe");
				}
			}
			
			//buscar
			@PostMapping (value ="/{idMascota}")
			public ResponseEntity<?> buscawr (@PathVariable int idMascota){
				Mascotas encontrada = service.buscar(idMascota);
				if(encontrada != null) {
					return ResponseEntity.ok(encontrada);
				}else {
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Este id no se encuentra en la base de datos");
				}
			}
			
			//eliminar
			@DeleteMapping(path ="/{idMascota}")
			public ResponseEntity<?> eliminar (@PathVariable int idMascota){
				Mascotas ser= service.buscar(idMascota);
				if( ser !=null) {
					service.eliminar(idMascota);
					return ResponseEntity.ok("Se elimino con esxito");
				}else {
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Operacion imposible no existe");
				}
			}
			
			
			//editar
			@PutMapping(path = "/{idMascota}")
		    public ResponseEntity<?> editar(@PathVariable("idMascota") int idMascota, @RequestBody Mascotas mascotas) {
				Mascotas encontrado = service.buscar(idMascota);
		        if(encontrado != null) {
		            // Actualizamos el evento con los nuevos datos 
		        	mascotas.setIdMascota(idMascota); // Aseguramos que el ID no cambie
		            service.editar(mascotas);
		            return ResponseEntity.ok("El registro fue actualizado con éxito");
		        } else {
		            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el registro para editar");
		        }
		    }

			
			//busca por veterinaria
			@GetMapping(path ="buscarPorVeterinaria/{veterinariaId}")
			public ResponseEntity<?> buscarPorVeterinaria(@PathVariable ("veterinariaId")int veterinariaId){
				List<Mascotas> mas = service.buscarPorVeterinaria(veterinariaId);
				return ResponseEntity.ok(mas);
			}

}
