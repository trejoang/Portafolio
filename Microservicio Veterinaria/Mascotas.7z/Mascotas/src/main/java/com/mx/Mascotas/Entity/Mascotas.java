package com.mx.Mascotas.Entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name ="MASCOTAS")
@Data
public class Mascotas {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_MASCOTA")
	private int idMascota;
	
	@Column(name = "NOMBRE")
	private String nombre;
	
	@Column(name = "RAZA")
	private String raza;

	@Column(name = "EDAD")
	private int edad;
	
	@Column(name = "RAZON_CITA")
	private String razonCita;
	
	@Column(name = "CLIENTE_ID")
	private int clienteId;
	
	@Column(name = "RESPONSABLE_ID")
	private int responsableId;

	@Column(name = "VETERINARIA_ID")
	private int veterinariaId;

}
