package com.mx.Veterinaria.OpenFeingClient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mx.Veterinaria.Entidades.Responsables;

@FeignClient(name ="Responsables", url = "http://localhost:8016", path ="/R" )
public interface IResponsablesFeingClient {
	
	@GetMapping(path ="buscarPorVeterinaria/{veterinariaId}")
	public List<Responsables> buscarPorVeterinaria(@PathVariable ("veterinariaId")int veterinariaId);

}
