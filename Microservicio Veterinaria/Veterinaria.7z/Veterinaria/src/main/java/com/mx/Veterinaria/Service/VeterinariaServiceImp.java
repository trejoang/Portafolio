package com.mx.Veterinaria.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mx.Veterinaria.Entidades.Clientes;
import com.mx.Veterinaria.Entidades.Mascotas;
import com.mx.Veterinaria.Entidades.Responsables;
import com.mx.Veterinaria.Entity.Veterinaria;
import com.mx.Veterinaria.OpenFeingClient.IMascotasFeingClient;
import com.mx.Veterinaria.OpenFeingClient.IResponsablesFeingClient;
import com.mx.Veterinaria.Repository.VeterinariaRepository;

@Service
public class VeterinariaServiceImp implements iVeterinariaService{
	
	@Autowired
	private VeterinariaRepository dao;

	@Override
	public List<Veterinaria> listar() {
		// TODO Auto-generated method stub
		return dao.findAll(Sort.by(Sort.Direction.ASC, "idVeterinaria"));
	}

	@Override
	public void guardar(Veterinaria veterinaria) {
		// TODO Auto-generated method stub
		dao.save(veterinaria);
	}

	@Override
	public Veterinaria buscar(int idVeterinaria) {
		// TODO Auto-generated method stub
		return dao.findById(idVeterinaria).orElse(null);
	}

	@Override
	public void editar(Veterinaria veterinaria) {
		// TODO Auto-generated method stub
		dao.save(veterinaria);
	}

	@Override
	public void eliminar(int idVeterinaria) {
		// TODO Auto-generated method stub
		dao.deleteById(idVeterinaria);
	}
	
	// metodos de microservicios
	@Autowired
	private RestTemplate restTemplate;
	//clientes
	public List<Clientes> obtenerClientes(int veterinariaId){
		@SuppressWarnings("unchecked")
		List<Clientes> clientes = restTemplate.getForObject("http://localhost:8018/C/buscarPorVeterinaria/" + veterinariaId, List.class);
		return clientes;
	}
	
	//metodo para listar Responsables
	@Autowired
	private IResponsablesFeingClient resFC;
	
	private List<Responsables> obtenerResponsables(int veterinariaId){
		List<Responsables> resp = resFC.buscarPorVeterinaria(veterinariaId);
		return resp;
	}
	
	//metodo para listar Mascotas
		@Autowired
		private IMascotasFeingClient masFC;
		
		private List<Mascotas> obtenerMascotas(int veterinariaId){
			List<Mascotas> masc = masFC.buscarPorVeterinaria(veterinariaId);
			return masc;
		}
		
		
		//metodo para listar toda la informacion sobre el veterinaria
		
		public Map<String, Object> getEventoAndModulos(int veterinariaId){
			
			Map<String, Object> resultado = new HashMap<>();
			
			//consultar si existe la veterinaria
			
			Veterinaria veterinaria = dao.findById(veterinariaId).orElse(null);
			if(veterinaria ==null) {
				resultado.put("Veterinaria mensaje:", "Esta veterinaria no existe");
			}else {
				resultado.put("veterinaria:", veterinaria);
				//consulta y validacion de clientes
				List<Clientes> clientes = obtenerClientes(veterinariaId);
				if(clientes.isEmpty()) {
					resultado.put("Clientes mensaje:", "sin clientes");
				}else {
					resultado.put("clientes disponibles:", clientes);
				}//cierre de clientes
				
				//consulta y validacion de Responsables
				List<Responsables> responsables = obtenerResponsables(veterinariaId);
				if(responsables.isEmpty()) {
					resultado.put("Responsables mensaje:", "sin responsables");
				}else {
					resultado.put("responsables disponibles:", responsables);
				}//cierre de responsables
				
				//consulta y validacion de Mascotas
				List<Mascotas> mascotas = obtenerMascotas(veterinariaId);
				if(mascotas.isEmpty()) {
					resultado.put("Mascotas mensaje:", "sin mascotas");
				}else {
					resultado.put("mascotas disponibles:", mascotas);
				}//cierre de mascotas
				
			}//cierre de validacion veterinarias
			return resultado;
		}
}
