package com.mx.Veterinaria.Entidades;

import lombok.Data;

@Data
public class Responsables {
	
	private int idResponsable;
	private String nombre;
	private int contacto;
	private int veterinariaId;

}
