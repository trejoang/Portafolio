package com.mx.Veterinaria.Entidades;

import lombok.Data;

@Data
public class Clientes {
	
	private int idCliente;
    private String nombre;
    private String direccion;
    private int contacto;

}
