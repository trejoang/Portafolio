package com.mx.Veterinaria.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mx.Veterinaria.Entidades.Clientes;
import com.mx.Veterinaria.Entity.Veterinaria;
import com.mx.Veterinaria.Service.VeterinariaServiceImp;

@RestController
@RequestMapping(path ="/V")

public class VeterinariaWS {
	
	@Autowired
	private VeterinariaServiceImp service;
	
	//url  http://localhost:8015/V
	
		@GetMapping
		public ResponseEntity<?> listar(){
			List<Veterinaria> veterinarias = service.listar();
			if(veterinarias.isEmpty()) {
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No existen registros en esta bd");
			}else {
				return ResponseEntity.ok(veterinarias);
			}
		}
		
		//guardar   http://localhost:8015/V/guardar
		@PostMapping
		public ResponseEntity<?> guardar(@RequestBody Veterinaria veterinaria){
		    try {
		    	Veterinaria encontrado = service.buscar(veterinaria.getIdVeterinaria());
		    	if(encontrado == null) {
		    		service.guardar(veterinaria);
		    		return ResponseEntity.ok("se registro exitosamente");
		    	}else {
		    		return ResponseEntity.status(HttpStatus.FOUND).body("este registro ya existe");
		    	}
		    }catch(IllegalArgumentException e) {
		    	return ResponseEntity.status(HttpStatus.CONFLICT).build();
		    }
		}
		
		//buscar  http://localhost:8015/V/buscar
		@PostMapping(path ="/{idVeterinaria}")
		public ResponseEntity<?> buscar(@PathVariable ("idVeterinaria") int idVeterinaria){
			Veterinaria encontrado = service.buscar(idVeterinaria);
			if(encontrado != null) {
				return ResponseEntity.ok(encontrado);
			}else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("no se encontro registro con ese id");
			}
		}
		
		//eliminar   http://localhost:8015/V/eliminar
		@DeleteMapping(path = "/{idVeterinaria}")
		public ResponseEntity<?> eliminar(@PathVariable int idVeterinaria){
			Veterinaria encontrado = service.buscar(idVeterinaria);
			if(encontrado != null) {
				service.eliminar(idVeterinaria);
				return ResponseEntity.ok("el registro fue eliminado con exito");
			}else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body("este registro no se puede eliminar xq no existe");
			}
		}
		
		//editar
		@PutMapping(path = "/{idVeterinaria}")
	    public ResponseEntity<?> editar(@PathVariable("idVeterinaria") int idVeterinaria, @RequestBody Veterinaria veterinaria) {
	        Veterinaria encontrado = service.buscar(idVeterinaria);
	        if(encontrado != null) {
	            // Actualizamos el evento con los nuevos datos
	        	veterinaria.setIdVeterinaria(idVeterinaria);  // Aseguramos que el ID no cambie
	            service.editar(veterinaria);
	            return ResponseEntity.ok("El registro fue actualizado con éxito");
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el registro para editar");
	        }
	    }
		
		// metodos que consumen microservicios
		//Clientes
		// URL del metodo http://localhost:8015/V/Cliente/veterinariaId
		@GetMapping("/Cliente/{veterinariaId}")
		public ResponseEntity<?> mostrarClientesPOrVeterinaria(@PathVariable int veterinariaId){
			try {
				Veterinaria aux = service.buscar(veterinariaId);
				if (aux == null) {
					return ResponseEntity.badRequest().body("No existen veterinarias con ese id");
				}else {
					List<Clientes> clientes = service.obtenerClientes(veterinariaId);
					if(clientes.isEmpty()) {
						return ResponseEntity.ofNullable("la veterinaria no tiene clientes");
					}else {
						return ResponseEntity.ok(clientes);
					}
				}
			}catch(Exception e) {
	    		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ocurrio un error el servicio no esta disponible"+ e.getMessage());
	    	}
		}
		
		//endpoint para listar todo
	    @GetMapping("/todo/{veterinariaId}")
	    public ResponseEntity<?> listarTodo(@PathVariable int veterinariaId){
	    	Map<String, Object> resultado = service.getEventoAndModulos(veterinariaId);
	    	return ResponseEntity.ok(resultado);
	    }

}
