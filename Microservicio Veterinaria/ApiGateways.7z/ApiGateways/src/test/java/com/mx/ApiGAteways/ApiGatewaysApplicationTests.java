package com.mx.ApiGAteways;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewaysApplicationTests {

	@Test
	void contextLoads() {
	}

}
