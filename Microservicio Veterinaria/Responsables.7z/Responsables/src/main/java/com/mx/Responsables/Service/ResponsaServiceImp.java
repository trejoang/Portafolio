package com.mx.Responsables.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.mx.Responsables.Entity.Responsables;
import com.mx.Responsables.Repository.IResponsablesRepository;
@Service
public class ResponsaServiceImp implements IResponsaService{
	
	@Autowired
	private IResponsablesRepository dao;

	@Override
	public List<Responsables> listar() {
		// TODO Auto-generated method stub
		return dao.findAll(Sort.by(Sort.Direction.ASC, "idResponsable"));
	}

	@Override
	public void guardar(Responsables responsables) {
		// TODO Auto-generated method stub
		dao.save(responsables);
	}

	@Override
	public Responsables buscar(int idResponsable) {
		// TODO Auto-generated method stub
		return dao.findById(idResponsable).orElse(null);
	}

	@Override
	public void editar(Responsables responsables) {
		// TODO Auto-generated method stub
		dao.save(responsables);
	}

	@Override
	public void eliminar(int idResponsable) {
		// TODO Auto-generated method stub
		dao.deleteById(idResponsable);
	}
	
	//metodo para buscar por veterinaria
		public List<Responsables> buscarPorVeterinaria(int veterinariaId){
			return dao.findByVeterinariaId(veterinariaId);
			
		}

}
