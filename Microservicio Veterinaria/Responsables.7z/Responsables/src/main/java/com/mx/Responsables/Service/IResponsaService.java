package com.mx.Responsables.Service;

import java.util.List;

import com.mx.Responsables.Entity.Responsables;

public interface IResponsaService {
	
	public List<Responsables> listar();
	public void guardar(Responsables responsables);
	public Responsables buscar(int idResponsable);
	public void editar(Responsables responsables);
	public void eliminar(int idResponsable);

}
