package com.mx.Responsables.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mx.Responsables.Entity.Responsables;
import com.mx.Responsables.Service.ResponsaServiceImp;

@RestController
@RequestMapping(path = "/R")
public class ResponsablesWS {
	
	@Autowired
	private ResponsaServiceImp service;
	
	//url  http://localhost:8016/R
	
		@GetMapping
		public ResponseEntity<?> listar(){
			List<Responsables> res = service.listar();
			if(res.isEmpty()) {
				return ResponseEntity.ofNullable("No hay registros disponibles");
			}else {
				return ResponseEntity.ok(res);
			}
		}
		
		//Guardar
				@PostMapping
				public ResponseEntity<?> guardar(@RequestBody Responsables responsable){
					Responsables res = service.buscar(responsable.getIdResponsable());
					if(res == null) {
						service.guardar(responsable);
						return ResponseEntity.ok("El registro del responsable se guardo con exito");
					}else {
						return ResponseEntity.status(HttpStatus.FOUND).body("Este Registro ya Existe");
					}
				}
				
				//buscar
				@PostMapping (value ="/{idResponsable}")
				public ResponseEntity<?> buscawr (@PathVariable int idResponsable){
					Responsables encontrada = service.buscar(idResponsable);
					if(encontrada != null) {
						return ResponseEntity.ok(encontrada);
					}else {
						return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Este id no se encuentra en la base de datos");
					}
				}
				
				//eliminar
				@DeleteMapping(path ="/{idResponsable}")
				public ResponseEntity<?> eliminar (@PathVariable int idResponsable){
					Responsables ser= service.buscar(idResponsable);
					if( ser !=null) {
						service.eliminar(idResponsable);
						return ResponseEntity.ok("Se elimino con esxito");
					}else {
						return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Operacion imposible no existe");
					}
				}
				
				
				//editar
				@PutMapping(path = "/{idResponsable}")
			    public ResponseEntity<?> editar(@PathVariable("idResponsable") int idResponsable, @RequestBody Responsables responsables) {
					Responsables encontrado = service.buscar(idResponsable);
			        if(encontrado != null) {
			            // Actualizamos el evento con los nuevos datos 
			        	responsables.setIdResponsable(idResponsable) ; // Aseguramos que el ID no cambie
			            service.editar(responsables);
			            return ResponseEntity.ok("El registro fue actualizado con éxito");
			        } else {
			            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el registro para editar");
			        }
			    }
				
				//busca por veterinaria
				@GetMapping(path ="buscarPorVeterinaria/{veterinariaId}")
				public ResponseEntity<?> buscarPorVeterinaria(@PathVariable ("veterinariaId")int veterinariaId){
					List<Responsables> res = service.buscarPorVeterinaria(veterinariaId);
					return ResponseEntity.ok(res);
				}
}
