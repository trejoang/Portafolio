package com.mx.Responsables;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResponsablesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResponsablesApplication.class, args);
	}

}
