package com.mx.Responsables.Entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name ="RESPONSABLES")
@Data
public class Responsables {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_RESPONSABLE")
	private int idResponsable;
	
	@Column(name = "NOMBRE")
	private String nombre;
	
	@Column(name = "CONTACTO")
	private int contacto;

	@Column(name = "VETERINARIA_ID")
	private int veterinariaId;

}
